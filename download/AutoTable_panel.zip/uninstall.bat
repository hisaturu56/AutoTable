@echo off
chcp 65001 >nul
set "DEST=%APPDATA%\Adobe\CEP\extensions\AutoTable"
if exist "%DEST%" rmdir /s /q "%DEST%"
echo テーブル自動作成のパネルを削除しました。Illustrator を再起動してください。
pause
