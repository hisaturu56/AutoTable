@echo off
chcp 65001 >nul
setlocal
set "SRC=%~dp0PolaroidTable"
set "DEST=%APPDATA%\Adobe\CEP\extensions\PolaroidTable"

rem 署名なしのパネルを読み込めるようにする（Illustrator のバージョンごとの設定）
for %%v in (9 10 11 12 13 14) do reg add "HKCU\Software\Adobe\CSXS.%%v" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul

if exist "%DEST%" rmdir /s /q "%DEST%"
xcopy "%SRC%" "%DEST%\" /e /i /y /q >nul
if errorlevel 1 (
  echo インストールに失敗しました。
  pause
  exit /b 1
)

echo.
echo ポロライドテーブル自動作成のパネルをインストールしました。
echo Illustrator を再起動して、
echo 「ウィンドウ」→「エクステンション」→「ポロライドテーブル自動作成」を開いてください。
echo.
pause
